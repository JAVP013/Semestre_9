x = -7

while x <= 7:
    y = round(x/2 + 1)
    print("(", x, ",", y, ")")
    x += 1
