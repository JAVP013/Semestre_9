x = -7
while x <= 7:
    y = x + 1
    print("(", x, ",", y, ")")
    x += 1
